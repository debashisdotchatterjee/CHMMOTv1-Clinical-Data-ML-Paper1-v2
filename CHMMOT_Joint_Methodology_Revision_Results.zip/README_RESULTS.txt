PLOS ONE restored original methodology -- data-driven numerical results.

THIS RUN FITS a genuine two-task shared-representation cumulative-logit model with
enforced own-organ MRI monotonicity, training-subject fused offsets, and independent
patient-level split-conformal calibration. Reference Frank-Hall/XGBoost results
are comparator analyses (when --skip-reference is absent).

Analysis limitations: (1) source labels may be deterministic MRI staging rules;
(2) workbook row order is not a time stamp; (3) fitted visit offsets cannot
be used for unseen patients, so held-out predictions use delta=0; (4) n=19
calibration patients implies wide coverage uncertainty and limited resolution;
(5) no external validation and no verified clinician-independent endpoint.

NO DECLARATION OF SUPERIORITY OR SATISFIED GUARANTEES WITHOUT RESULTS.
