# REPRODUCIBLE RESULTS — NOT A SUBMISSION MANUSCRIPT

Input file SHA256: `e3a006deb18cb3d50259028bf3e78a7babb45532fe17310b5532c855c6ade9ba`
Generated (UTC): 2026-10-26T16:57:13.644420+00:00
Observations: 219 listed records from 126 patient identifiers.
Source labels (five ordered categories) retained exactly except for case/whitespace normalization.
Reciprocity flags (>15% discrepancy on either organ): 16 records (not silently dropped).
No visit dates: row order does not represent validated temporal intervals.
Disjoint patient allocation: {'calibration': 19, 'test': 19, 'train': 68, 'tune': 20}.

## Primary endpoint and leakage controls
* Independent cardiac and hepatic Frank–Hall four-threshold XGBoost models; NOT a joint multitask likelihood.
* Primary held-out outcome: first-listed record for each unseen patient.
* Training patients contribute all visits with inverse-number-of-visits weights.
* Hyperparameter tuning uses development-only patient IDs, then final models refit on train+tune.
* Calibration patients are held out from ALL model selection and fitting; conformal evaluation uses one record per patient.
* The test partition is never used to tune, calibrate, fix data errors, or select the preferred model.
* Reported CIs are bootstrap CIs over held-out patients; small test sample yields substantial uncertainty.
* Source-defined ordinal categories may be derived from MRI measurements: high accuracy may represent reconstruction of staging rules, not prognostic discovery.

## Primary model results (do not copy numbers from previous paper)
* **Cardiac:** n_test=19, QWK=0.944, oMAE=0.158, RPS=0.034; conformal 17/19=0.895 (nominal 0.90), mean set size=1.05.
* **Hepatic:** n_test=19, QWK=0.850, oMAE=0.158, RPS=0.036; conformal 19/19=1.000 (nominal 0.90), mean set size=1.58.

## Interpretive safeguards
* Marginal split-conformal coverage is guaranteed only under exchangeability and independent proper calibration; category-specific coverage is NOT guaranteed.
* The calibration quantile is finite-sample corrected; with few calibration patients, set sizes and conditional coverage may be unstable.
* Contradictions in recorded R2*≈1000/T2*, categorical staging, and uncertain MIC generation require clinical source verification.
* Source versus clinical T2* thresholds are compared DESCRIPTIVELY: the five source labels are not assumed interchangeable with 3 SCMR-inspired groups.
* Permutation importance is reliance-on-features, not independent biological effect or causal importance.
* CV folds after tuning are descriptive robustness checks, not nested out-of-sample selection-adjusted performance.
* NO external dataset or clinical diagnosis reference standard was supplied. Do not claim external validation or improved clinical outcomes.
* No human subject identifiers or row-level predictions are included in the distributable ZIP.

## What to cite or include in the revised paper
Table 01–06: audit, frequencies, partitions; 07: tuning; 08: all held-out comparisons; 09–11: diagnostics;
Table 12: conformal results; 13: monotonicity; 14: feature-group dependence; 15: three-band descriptive staging;
Table 16–18: development CV, data-quality sensitivity and listed-record transitions; 08b: paired bootstrap differences.
Figures F01–F05: descriptive/QC; F06–F07: comparative ablation;
F08–F13: confusion, reliability, conformal, constraint checks, reliance and score distributions; S01–S03: supporting.

## Versions and algorithm settings
Python 3.13.16; pandas 2.2.3; numpy 2.1.3; sklearn 1.6.1; XGBoost 3.4.1.
Parameters: {'seed': 20261026, 'fast': False, 'bootstrap_repetitions': 600}.

## Review before publishing
Inspect `tables/01_cohort_integrity.csv`, `tables/04_measurement_dependence.csv`,
`tables/08_model_performance_comparison.csv`, `tables/12_conformal_summary.csv`,
`tables/13_monotonicity_verification_{organ}.csv`, and the PRIVATE flagged row list.
Seek clinical adjudication of discordant measurement/label records before changing labels.
Review the sample size and variability before asserting any performance improvement.
